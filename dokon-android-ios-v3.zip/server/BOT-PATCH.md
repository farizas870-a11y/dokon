# Botga qo'shiladigan kod (v2)

`server/api.js` ni bot fayli yoniga qo'ying (Node.js 18+, qo'shimcha paket kerak emas).

## 1) API ni ulash
Bot faylining oxiriga, `preloadAllData();` dan keyin va `bot.launch(...)` dan oldin:

```js
const createApi = require("./server/api");
const APP_URL = "https://SIZNING-ILOVA-MANZILINGIZ";
const appApi = createApi({
    secret: BOT_TOKEN,
    getOrders: () => loadJson(ORDERS_FILE, {}),
    store: { read: (f, d) => loadJson(f, d), write: (f, v) => saveJson(f, v) },
    isStaticAdmin: (id) => id === ADMIN_ID || id === ADMIN2_ID,
    isOwner: (id) => id === OWNER(),
    canPost: (id) => id === OWNER() || id === ADMIN_ID,
    isBanned: (id) => isBanned(id),
    growth: "double",
    port: 3000,
    getBalance: (uid) => getBalance(uid),
    getCatalog: (uid) => {
        const b = getActiveBonus(), k = getKonkurs();
        const list = (a) => a.map((x, i) => ({ i, name: x.name, price: x.price }));
        return {
            bonus: b ? { amount: b.amount, until: b.untilDate, untilTs: b.untilTimestamp } : null,
            vpn: VPN_PRICES.map((price) => ({ price, inStock: vpnInStock(price) })),
            cnf: list(loadJson(CNF_STOCK_FILE, [])),
            account: loadJson(ACCOUNTS_FILE, []).map((x, i) => ({ i, name: accName(x), price: x.price })),
            solo: list(loadJson(SOLO_VPN_FILE, [])),
            ff: list(loadJson(FF_CHEATS_FILE, [])),
            fixPrice: FIX_VPN_PRICE,
            vip: isVipBuyer(uid),
            somPerStar: SOM_PER_STAR,
            blocked: { uzcard: (getCardBlock("uzcard") || {}).until || 0, humo: (getCardBlock("humo") || {}).until || 0 },
            konkurs: k ? { cond: k.cond, winners: k.winnersCount, joined: k.participants.includes(uid) } : null,
            reviews: loadJson(REVIEWS_FILE, []).length
        };
    },
    checkPromo: (uid, code) => {
        const p = loadPromos()[code];
        if (!p || p.used) return null;
        if (p.userId !== "all" && String(p.userId) !== String(uid)) return null;
        return { cat: p.category, percent: p.discountType === "percent" ? p.percent : 0, fixed: p.discountType === "fixed" ? p.amount : 0 };
    }
});

bot.command("app", (ctx) => {
    if (ctx.chat.type !== "private") return;
    registerUser(ctx.from.id);
    appApi.upsertUser(ctx.from);
    ctx.reply(
        "📱 Ilovaga kirish havolasi. U faqat sizniki, hech kimga yubormang:\n" +
        `${APP_URL}#t=${appApi.makeToken(ctx.from.id)}\n\n` +
        "ℹ️ Ilovada ismingiz, ID, obro'ngiz va buyurtmalaringiz egaga ko'rinadi."
    );
});
```

## 2) `/start` ni almashtiring (MUHIM)
Ilova botni `?start=buy_...`, `fix`, `reviews`, `konkurs` havolalari bilan ochadi. Eski `bot.start(...)` blokini shu bilan almashtiring:

```js
bot.start(async (ctx) => {
    const uid = ctx.from.id;
    delete userStates[uid];
    registerUser(uid);
    await ctx.reply("Assalomu alaykum! 👋\nKerakli bo'limni tanlang:", { parse_mode: "HTML", ...getMainKeyboard(uid) });
    const p = ctx.startPayload || "";

    if (p === "konkurs") return kShowUser(ctx);
    if (p === "reviews") {
        const all = loadJson(REVIEWS_FILE, []);
        if (!all.length) return ctx.reply("ℹ️ Hozircha otzivlar yo'q.");
        return ctx.reply("⭐️ <b>Qancha otziv ko'rmoqchisiz?</b>", { parse_mode: "HTML", ...reviewCountKeyboard() });
    }
    if (p === "fix") {
        userStates[uid] = { step: "WAIT_FIX_FILE" };
        return ctx.reply(`🛠 <b>ZAMEN VPN</b>\n\n💵 Narxi: <b>${FIX_VPN_PRICE.toLocaleString()} so'm</b>\n\n📁 To'g'rilanishi kerak bo'lgan <b>VPN faylini</b> (document) yuboring:`, { parse_mode: "HTML" });
    }

    // buy_<usul>_<tur>_<arg>  (usul: card | click | stars | balance)
    const m = p.match(/^buy_(?:card|click|stars|balance)_(vpn|solo|cnf|account|ff|topup)_(\d+)$/);
    if (!m) return;
    const kind = m[1], arg = m[2];
    if (kind === "topup") {
        const amount = parseInt(arg);
        return ctx.reply(`💰 <b>To'lov summasi: ${amount.toLocaleString()} so'm</b>\n\nTo'lov turini tanlang:`, {
            parse_mode: "HTML",
            ...Markup.inlineKeyboard([
                [Markup.button.callback("💳 Kartadan o'tkazma", `method_card_topup_${amount}`)],
                [Markup.button.callback("Click", `method_click_topup_${amount}`)],
                [Markup.button.callback("⭐️ Stars orqali", `method_stars_topup_${amount}`)]
            ])
        });
    }
    const r = resolveProduct(kind, arg, uid);
    if (!r) return ctx.reply(NOT_FOUND_TEXT);
    if (kind === "vpn" && !vpnInStock(r.amount)) return ctx.reply("⚠️ Bu tarif zaxirasi hozircha tugagan.");
    return ctx.reply(`${r.sumLine}\n\nJoriy balansingiz: <b>${getBalance(uid).toLocaleString()} so'm</b>\nTo'lov turini tanlang:`, {
        parse_mode: "HTML",
        ...Markup.inlineKeyboard([
            [Markup.button.callback("💳 Kartadan o'tkazma", `method_card_${kind}_${arg}`)],
            [Markup.button.callback("Click", `method_click_${kind}_${arg}`)],
            [Markup.button.callback("⭐️ Stars orqali", `method_stars_${kind}_${arg}`)],
            [Markup.button.callback(`💰 Balansdan (${r.payAmount.toLocaleString()} so'm)`, `pay_balance_${kind}_${arg}`)]
        ])
    });
});
```

## 3) Ilova sozlamasi
`www/index.html` ichida `API_URL=""` ga serveringiz HTTPS manzilini, `BOT_USERNAME` ga bot nomini (@ siz) yozing. Port 3000 ni Nginx yoki Cloudflare Tunnel orqali HTTPS ga chiqaring.

## Ilovada endi nima bor
- Katalog, bonus, balans, VIP holati, VPN zaxirasi: botdan jonli keladi (12 ta tarif, zaxirasi tugaganlari o'chirilgan ko'rinadi).
- Zamen VPN (100 000 so'm): do'kon bo'limining tepasida, bosilsa botda fayl so'raydi.
- Konkurs va Otzivlar: "Aloqa" bo'limida, botga o'tkazadi.
- Uzcard/Humo bloklangan bo'lsa, to'lov oynasida ogohlantirish chiqadi; ikkalasi bloklansa karta tugmasi o'chadi.
- Promokod: server tekshiradi, faqat o'z kategoriyasiga chegirma ko'rsatadi.
- Balansdan to'lash: botda tasdiqlanadi (pul yechish va yetkazish botda bo'ladi).
- Banlangan foydalanuvchiga ilova "Siz botdan banlangansiz" deydi.

Eslatma: obuna majburiy kanallari (REQUIRED_CHANNELS) botda tekshiriladi; yangi foydalanuvchi havola orqali kelsa, obuna bo'lgach havolani qayta bosishi kerak.

---
# v3: hamma narsa ilovaning ichida (botga o'tmaydi)

`createApi({...})` ichiga (oldingi `getCatalog` yoniga) quyidagilarni qo'shing. `getCatalog` qaytaradigan obyektga `cards` maydonini ham qo'shing:

```js
cards: {
    uzcard: { number: CARD_TRANSFER_NUMBER, owner: CARD_TRANSFER_OWNER },
    humo:   { number: HUMO_CARD_NUMBER,     owner: HUMO_CARD_OWNER },
    click:  { number: CLICK_CARD_NUMBER,    owner: CLICK_CARD_OWNER }
},
```

```js
    fileUrl: (id) => bot.telegram.getFileLink(id).then(String),
    contact: (uid, name, text) => sendContactToStaff(uid, name, escapeHtml(text)),

    // To'langan buyurtma ichidagi narsalar (fayl/video/matn)
    deliveryItems: (o) => {
        if (o.product === "vpn") {
            const it = loadJson(VPN_STOCK_FILE, {})[o.amount], t = loadJson(TUTORIAL_FILE, {}) || {}, out = [];
            if (it && it.file_id) out.push({ t: "file", label: "VPN fayli", file_id: it.file_id, name: it.file_name || "vpn.conf" });
            if (t.android && t.android.video_id) out.push({ t: "video", label: "Android darslik videosi", file_id: t.android.video_id, name: "android-darslik.mp4" });
            if (t.iphone && t.iphone.video_id) out.push({ t: "video", label: "iPhone darslik videosi", file_id: t.iphone.video_id, name: "iphone-darslik.mp4" });
            return out;
        }
        if (o.product === "cnf" && o.cnfData) return [{ t: "file", label: o.cnfData.name, file_id: o.cnfData.file_id, name: o.cnfData.name }];
        if (o.product === "solo_vpn" && o.soloData) return [{ t: "file", label: o.soloData.name, file_id: o.soloData.file_id, name: o.soloData.name }];
        if (o.product === "account" && o.accountData) return [{ t: "text", label: o.accountData.name || "Akkaunt", text: `Email: ${o.accountData.email}\nParol: ${o.accountData.password}` }];
        if (o.product === "ff" && o.ffData) return o.ffData.kind === "text"
            ? [{ t: "text", label: o.ffData.name, text: o.ffData.text }]
            : [{ t: "file", label: o.ffData.name, file_id: o.ffData.file_id, name: o.ffData.file_name || o.ffData.name }];
        return [];
    },

    // Balansdan xarid (pul yechiladi, buyurtma "paid" bo'ladi)
    buyBalance: async (uid, kind, arg) => {
        if (kind === "fix") return { error: "Zamen VPN hozircha botda" };
        const r = resolveProduct(kind, arg, uid);
        if (!r) return { error: "Mahsulot topilmadi yoki sotilgan" };
        if (getBalance(uid) < r.payAmount) return { error: "Balans yetarli emas" };
        if (kind === "account" && !findAccountByEmail(r.item.email)) return { error: "Akkaunt sotilib bo'lgan" };
        if (kind === "vpn" && !vpnInStock(r.amount)) return { error: "Zaxira tugagan" };
        const balance = deductBalance(uid, r.payAmount);
        if (kind === "account") removeAccountByEmail(r.item.email);
        const orderId = `order_${uid}_${Date.now()}`;
        const orders = loadJson(ORDERS_FILE, {});
        orders[orderId] = { userId: uid, amount: r.amount, payAmount: r.payAmount, product: r.product, ...r.extra, method: "balance", status: "paid" };
        saveJson(ORDERS_FILE, orders);
        if (kind === "vpn") { addVpnBuyer(uid); if (r.amount >= VIP_MIN_PRICE) addVipBuyer(uid); }
        if (r.promo) consumePromo(r.promo.code);
        konkursOnPurchase(uid).catch(() => {});
        return { ok: true, orderId, balance };
    },

    // Karta/Click chekini adminga yuborish (admin botda tasdiqlaydi)
    submitReceipt: async (uid, name, kind, arg, method, cardType, buf) => {
        let base;
        if (kind === "topup") {
            const a = parseInt(arg);
            if (!(a > 0)) return { error: "Summa noto'g'ri" };
            base = { product: "topup", amount: a, payAmount: a };
        } else {
            if (kind === "fix") return { error: "Zamen VPN hozircha botda" };
            const r = resolveProduct(kind, arg, uid);
            if (!r) return { error: "Mahsulot topilmadi" };
            base = { product: r.product, amount: r.amount, payAmount: r.payAmount, promoCode: r.promo ? r.promo.code : null, ...r.extra };
        }
        const m = await bot.telegram.sendPhoto(ADMIN_ID, { source: buf });
        const photoId = m.photo[m.photo.length - 1].file_id;
        bot.telegram.deleteMessage(ADMIN_ID, m.message_id).catch(() => {});
        const orderId = `order_${uid}_${Date.now()}`, isFf = base.product === "ff";
        const orders = loadJson(ORDERS_FILE, {});
        orders[orderId] = { userId: uid, ...base, method, cardType: cardType || null, status: isFf ? "pending_ff" : "pending", photoId, firstName: name };
        saveJson(ORDERS_FILE, orders);
        if (isFf) await sendFfOrderToAdmins(orderId, orders[orderId]);
        else await sendOrderToAdmin(orderId, orders[orderId], photoId, name);
        await notifyOwnerCopy(orders[orderId]);
        return { ok: true, orderId };
    },
```

Qanday ishlaydi: ilovada Karta/Click tanlansa, karta raqami chiqadi, foydalanuvchi chek rasmini yuklaydi, chek adminga botda keladi. Admin botda "Tasdiqlash" bossa, buyurtma ilovada "Bajarildi" bo'ladi va "Ochish" tugmasi orqali fayl/video/akkaunt ma'lumoti ilovaning o'zida olinadi.

Cheklovlar:
- Telegram Stars faqat Telegram ichida to'lanadi, shuning uchun ilovadan olib tashlandi.
- Telegram botlari 20 MB gacha fayl yuklab bera oladi. Undan katta video/faylni ilova ola olmaydi (kichikroq qilib qayta yuklang).
- Zamen VPN, Konkurs va Otzivlar hozircha botga o'tkazadi.
- Admin "Qayta chek so'rash" bosganda so'rov botga ketadi.
