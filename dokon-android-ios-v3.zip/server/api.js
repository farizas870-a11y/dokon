// Ilova API: buyurtmalar, vazifalar, obro', ega paneli. Tashqi kutubxona kerak emas (Node.js 18+).
const http = require("http");
const crypto = require("crypto");
const { Readable } = require("stream");

const MAXL = 50;

module.exports = function createApi({
    secret, getOrders, store, isStaticAdmin, isOwner, canPost, isBanned = () => false,
    getCatalog = () => ({}), getBalance = () => 0, checkPromo = () => null,
    deliveryItems = () => [], buyBalance = async () => ({ error: "yoq" }), submitReceipt = async () => ({ error: "yoq" }), contact = async () => {}, fileUrl = async () => "",
    port = 3000, ttlDays = 30, growth = "double" // growth: "double" (4,8,16...) yoki "linear" (4,8,12...)
}) {
    const key = crypto.createHash("sha256").update("app-token:" + secret).digest();
    const sign = (p) => crypto.createHmac("sha256", key).update(p).digest("hex").slice(0, 32);
    const makeToken = (id) => { const p = `${id}.${Date.now() + ttlDays * 864e5}`; return `${p}.${sign(p)}`; };
    function verify(token) {
        const [uid, exp, sig, extra] = String(token || "").split(".");
        if (!uid || !exp || !sig || extra !== undefined) return null;
        const good = sign(`${uid}.${exp}`);
        if (sig.length !== good.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(good))) return null;
        if (!(Number(exp) > Date.now())) return null;
        const id = Number(uid);
        return Number.isSafeInteger(id) ? id : null;
    }

    const need = (n) => (growth === "linear" ? 4 * n : 4 * Math.pow(2, n - 1));
    function repOf(done) {
        let level = 0, left = done;
        while (level < MAXL && left >= need(level + 1)) { left -= need(level + 1); level++; }
        return { level, into: left, need: level < MAXL ? need(level + 1) : 0, done };
    }

    const U = () => store.read("app_users.json", {});
    const T = () => store.read("app_tasks.json", []);
    const A = () => store.read("app_admins.json", []);
    const isAdmin = (id) => isOwner(id) || isStaticAdmin(id) || A().includes(id);

    function newPid(users) {
        const used = new Set(Object.values(users).map((u) => u.pid));
        let pid; do { pid = String(100000 + crypto.randomInt(900000)); } while (used.has(pid));
        return pid;
    }
    function ensureUser(id, from) {
        const users = U();
        let u = users[id];
        if (!u) { u = users[id] = { pid: newPid(users), name: "", username: "", joined: new Date().toISOString().slice(0, 10), last: "", done: 0, doneIds: [] }; }
        if (from) { u.name = from.first_name || u.name; u.username = from.username || u.username; }
        u.last = new Date().toISOString().slice(0, 10);
        store.write("app_users.json", users);
        return u;
    }
    function activeTasks() {
        const all = T(), live = all.filter((t) => t.expiresAt > Date.now());
        if (live.length !== all.length) store.write("app_tasks.json", live); // 1 kundan keyin o'chadi
        return live;
    }

    const maskEmail = (e) => { const [u, d] = String(e).split("@"); return d ? u.slice(0, 2) + "***@" + d : "***"; };
    function titleOf(o) {
        switch (o.product) {
            case "vpn": return `VPN (${Number(o.amount).toLocaleString("ru-RU")} so'm)`;
            case "cnf": return `CNF: ${o.cnfData && o.cnfData.name}`;
            case "solo_vpn": return `Alohida VPN: ${o.soloData && o.soloData.name}`;
            case "account": return `Akkaunt: ${o.accountData ? maskEmail(o.accountData.email) : ""}`;
            case "ff": return `FF chit: ${o.ffData && o.ffData.name}`;
            case "fix": return "Zamen VPN";
            case "topup": return "Balans to'ldirish";
            case "unban": return "Tezda unban";
            default: return String(o.product);
        }
    }
    const statusOf = (s) => (s === "paid" ? "paid" : (s === "rejected" || s === "banned" || s === "refunded") ? "rejected" : "pending");
    function orderView(id, o, level) { // level: "own" | "admin" | "owner"
        const base = { id, title: titleOf(o), sum: o.payAmount || o.amount, method: o.method || "card", status: statusOf(o.status), delivery: ["vpn", "cnf", "solo_vpn", "account", "ff"].includes(o.product), ts: parseInt(id.split("_").pop()) || 0 };
        if (level === "own") return base;
        const u = U()[o.userId];
        const admin = { ...base, pid: u ? u.pid : "-" }; // admin faqat 6 xonali ID ni ko'radi
        return level === "owner" ? { ...admin, userId: o.userId, firstName: o.firstName || "" } : admin;
    }

    function readBody(req, max = 10000) {
        return new Promise((resolve) => {
            let b = ""; req.on("data", (c) => { b += c; if (b.length > max) req.destroy(); });
            req.on("end", () => { try { resolve(JSON.parse(b || "{}")); } catch (e) { resolve({}); } });
        });
    }

    const server = http.createServer(async (req, res) => {
        res.setHeader("Access-Control-Allow-Origin", "*"); // kirish tokenli (cookie yo'q)
        res.setHeader("Access-Control-Allow-Headers", "Authorization, Content-Type");
        res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        if (req.method === "OPTIONS") { res.writeHead(204); return res.end(); }
        const send = (code, body) => { res.writeHead(code, { "Content-Type": "application/json", "Cache-Control": "no-store" }); res.end(JSON.stringify(body)); };

        const qt = new URL(req.url, "http://x").searchParams.get("t") || "";
        const uid = verify((req.headers.authorization || "").replace(/^Bearer /, "") || qt);
        if (!uid) return send(401, { error: "unauthorized" });
        if (isBanned(uid)) return send(403, { error: "banned" });

        const path = req.url.split("?")[0], me = ensureUser(uid), orders = getOrders();
        const owner = isOwner(uid), admin = isAdmin(uid);

        const m0 = path.match(/^\/api\/(deliveries|file)\/([^/]+)(?:\/(\d+))?$/);
        if (req.method === "GET" && m0) { // faqat o'z, to'langan buyurtma
            const o = orders[decodeURIComponent(m0[2])];
            if (!o || String(o.userId) !== String(uid) || o.status !== "paid") return send(404, { error: "order" });
            const items = deliveryItems(o);
            if (m0[1] === "deliveries") return send(200, items.map((x, i) => ({ i, t: x.t, label: x.label, text: x.text })));
            const x = items[Number(m0[3])];
            if (!x || !x.file_id) return send(404, { error: "file" });
            try {
                const r = await fetch(await fileUrl(x.file_id));
                if (!r.ok) throw new Error("tg");
                const name = String(x.name || "file").replace(/[^\w.\- ]/g, "_");
                res.writeHead(200, { "Content-Type": "application/octet-stream", "Content-Disposition": `attachment; filename="${name}"`, "Cache-Control": "no-store" });
                return Readable.fromWeb(r.body).pipe(res);
            } catch (e) { return send(502, { error: "file_unavailable" }); }
        }
        if (req.method === "GET") {
            if (path === "/api/me") return send(200, { role: owner ? "owner" : admin ? "admin" : "user", canPost: !!canPost(uid), pid: me.pid, rep: repOf(me.done), balance: getBalance(uid) });
            if (path === "/api/catalog") return send(200, getCatalog(uid));
            if (path === "/api/orders") {
                return send(200, Object.keys(orders).filter((id) => String(orders[id].userId) === String(uid))
                    .map((id) => orderView(id, orders[id], "own")).sort((a, b) => b.ts - a.ts));
            }
            if (path === "/api/tasks") return send(200, activeTasks().map((t) => ({ id: t.id, title: t.title, desc: t.desc, expiresAt: t.expiresAt, done: me.doneIds.includes(t.id) })));
            if (path === "/api/admin/orders") {
                if (!admin) return send(403, { error: "forbidden" });
                return send(200, Object.keys(orders).map((id) => orderView(id, orders[id], owner ? "owner" : "admin")).sort((a, b) => b.ts - a.ts));
            }
            if (path === "/api/owner/users") { // faqat ega: hamma foydalanuvchi ma'lumoti
                if (!owner) return send(403, { error: "forbidden" });
                const users = U(), adm = A();
                return send(200, Object.keys(users).map((id) => {
                    const u = users[id], mine = Object.values(orders).filter((o) => String(o.userId) === id);
                    return { userId: Number(id), pid: u.pid, name: u.name, username: u.username, joined: u.joined, last: u.last, done: u.done,
                        level: repOf(u.done).level, orders: mine.length, spent: mine.filter((o) => o.status === "paid" && o.product !== "topup").reduce((s, o) => s + (o.payAmount || o.amount || 0), 0),
                        isAdmin: adm.includes(Number(id)) || isStaticAdmin(Number(id)) };
                }).sort((a, b) => b.level - a.level || b.done - a.done));
            }
        }

        if (req.method === "POST") {
            const body = await readBody(req, path === "/api/receipt" ? 12e6 : 10000);
            if (path === "/api/buy") {
                const r = await buyBalance(uid, String(body.kind), String(body.arg));
                return send(r.ok ? 200 : 400, r);
            }
            if (path === "/api/receipt") {
                const buf = Buffer.from(String(body.photo || ""), "base64");
                if (buf.length < 100) return send(400, { error: "photo" });
                const r = await submitReceipt(uid, me.name || String(uid), String(body.kind), String(body.arg), body.method === "click" ? "click" : "card", body.cardType === "humo" ? "humo" : "uzcard", buf);
                return send(r.ok ? 200 : 400, r);
            }
            if (path === "/api/contact") {
                const t = String(body.text || "").trim().slice(0, 1500);
                if (!t) return send(400, { error: "text" });
                await contact(uid, me.name || String(uid), t);
                return send(200, { ok: true });
            }
            if (path === "/api/promo") {
                const p = checkPromo(uid, String(body.code || "").trim().toUpperCase().replace(/\s+/g, ""));
                return p ? send(200, p) : send(404, { error: "promo" });
            }
            if (path === "/api/tasks") { // faqat ega va 1-admin
                if (!canPost(uid)) return send(403, { error: "forbidden" });
                const title = String(body.title || "").trim().slice(0, 120);
                if (!title) return send(400, { error: "title" });
                const all = activeTasks();
                all.push({ id: "t" + Date.now().toString(36) + crypto.randomInt(1000), title, desc: String(body.desc || "").trim().slice(0, 300), by: uid, createdAt: Date.now(), expiresAt: Date.now() + 864e5 });
                store.write("app_tasks.json", all);
                return send(200, { ok: true });
            }
            const m = path.match(/^\/api\/tasks\/([^/]+)\/done$/);
            if (m) {
                const id = decodeURIComponent(m[1]);
                if (!activeTasks().some((t) => t.id === id)) return send(404, { error: "task" });
                const users = U(), u = users[uid];
                if (!u.doneIds.includes(id)) { u.doneIds.push(id); u.done++; u.doneIds = u.doneIds.slice(-200); store.write("app_users.json", users); }
                return send(200, { rep: repOf(u.done) });
            }
            if (path === "/api/owner/admin" || path === "/api/owner/admin/remove") { // faqat ega: 6 xonali ID bilan
                if (!owner) return send(403, { error: "forbidden" });
                const users = U(), id = Object.keys(users).find((k) => users[k].pid === String(body.pid));
                if (!id) return send(404, { error: "pid" });
                let adm = A().filter((x) => x !== Number(id));
                if (path === "/api/owner/admin") adm.push(Number(id));
                store.write("app_admins.json", adm);
                return send(200, { ok: true });
            }
        }
        send(404, { error: "not_found" });
    });

    server.listen(port, () => console.log("🔐 API port " + port + " da ishlayapti"));
    return { makeToken, verify, server, upsertUser: (from) => ensureUser(from.id, from) };
};
