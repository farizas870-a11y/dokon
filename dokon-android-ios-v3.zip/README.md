# Raqamli do'kon: Android (APK) va iOS

Avval `www/index.html` ichida `BOT_USERNAME="YOUR_BOT_USERNAME"` ni botingiz nomiga almashtiring (@ siz).

## Android: APK olish

### A usul: kompyuterga hech narsa o'rnatmasdan (GitHub)
1. github.com da bo'sh repo oching va shu papkadagi hamma fayllarni (`.github` papkasi bilan) yuklang.
2. Repo > Actions > "Build APK" > Run workflow.
3. 5-10 daqiqadan keyin tugagan ishga kiring, pastdagi Artifacts ichidan `dokon-apk` ni yuklab oling.
4. Zip ichidagi `app-debug.apk` ni telefonga o'tkazing va oching. "Noma'lum manbalardan o'rnatish" ruxsatini bering.

### B usul: o'z kompyuteringizda
Kerak: Node.js 18+, JDK 17, Android Studio (SDK).
```
npm install
npx cap add android
npx cap sync android
cd android && ./gradlew assembleDebug
```
Fayl: `android/app/build/outputs/apk/debug/app-debug.apk`

Play Marketga yuklash uchun imzolangan (release) AAB kerak. Buning uchun Android Studio > Build > Generate Signed Bundle.

## iOS
APK ning iOS dagi analogi yo'q. Ikki yo'l bor:
1. Tez va bepul: `www` papkani HTTPS hostingga joylang (GitHub Pages, Netlify, Cloudflare Pages). iPhone da Safari bilan oching > Ulashish > "Bosh ekranga qo'shish". Ilova alohida ikonka bilan, to'liq ekranda ochiladi.
2. Haqiqiy iOS ilova (.ipa): Mac, Xcode va Apple Developer hisobi (yiliga $99) kerak. `npm i @capacitor/ios && npx cap add ios && npx cap open ios`.

## Android da ham hosting orqali
`www` ni hostingga joylasangiz, Chrome > menyu > "Ilovani o'rnatish" orqali ham o'rnatiladi (APK shart emas).

## Obro', vazifalar va maxfiylik
Botga `server/api.js` ni ulash uchun `server/BOT-PATCH.md` ga qarang (v2: katalog, balans, Zamen VPN, konkurs, otzivlar, promokod). Ulanmaguncha ilova demo rejimida ishlaydi.
